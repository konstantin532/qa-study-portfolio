/* QA Study Portfolio — toast lifecycle recovery
   Подключать после основных JS-файлов приложения. */
(() => {
  "use strict";

  const LIFE = 3000;
  const EXIT = 220;
  const timers = new WeakMap();

  function textKey(toast) {
    const node = toast.querySelector(".toast-message, .toast-content, .toast-title") || toast;
    return (node.textContent || "")
      .replace(/[×✕]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function removeToast(toast) {
    if (!(toast instanceof HTMLElement) || !toast.isConnected) return;
    const timer = timers.get(toast);
    if (timer) clearTimeout(timer);
    timers.delete(toast);
    toast.classList.add("is-closing");
    window.setTimeout(() => toast.remove(), EXIT);
  }

  function armToast(toast) {
    if (!(toast instanceof HTMLElement) || timers.has(toast)) return;

    toast.classList.add("toast-managed");
    const close = toast.querySelector(".toast-close, [data-toast-close]");
    if (close) {
      close.addEventListener("click", () => removeToast(toast), { once: true });
    }

    timers.set(toast, window.setTimeout(() => removeToast(toast), LIFE));
  }

  function processContainer(container) {
    if (!(container instanceof HTMLElement)) return;

    const seen = new Map();
    container.querySelectorAll(".toast").forEach((toast) => {
      const key = textKey(toast);
      if (key && seen.has(key)) removeToast(seen.get(key));
      if (key) seen.set(key, toast);
      armToast(toast);
    });
  }

  function scan(root = document) {
    root.querySelectorAll?.(".toast-container, #toast-container").forEach(processContainer);

    if (root instanceof HTMLElement && root.matches(".toast")) {
      const container = root.closest(".toast-container, #toast-container");
      if (container) processContainer(container);
    }
  }

  function start() {
    scan(document);

    const observer = new MutationObserver((records) => {
      records.forEach((record) => {
        record.addedNodes.forEach((node) => {
          if (!(node instanceof HTMLElement)) return;
          scan(node);
          const container = node.closest?.(".toast-container, #toast-container");
          if (container) processContainer(container);
        });
      });
    });

    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
